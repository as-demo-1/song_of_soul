﻿
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "DialogueStatus", menuName = "Dialogue/DialogueStatus")]
public class DialogueStatusSO : ScriptableObject
{
    [Tooltip("ConditionName")]
    [SerializeField] private string _conditionname = default;
    [Tooltip("ConditionID")]
    [SerializeField] private string _conditionid = default;
    [Tooltip("是否达成")]
    [SerializeField] private int _judge = default;

    public int Judge => _judge;
    public string ConditionName => _conditionname;
    public string ConditionID => _conditionid;


    //public bool IsInit => _isInit;

    /*public void SetConditionNos()
    {
        if (_isInit) return;
        foreach (IfDialogueSO item in IfDialogueList)
        {
            _conditionNos.Add(item.ConditionID, item.ConditionNo);
        }
        _isInit = true;
    }
    
    private void Awake()
    {
        SetConditionNos();
    }*/
}
