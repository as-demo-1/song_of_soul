﻿using UnityEngine;
using System.Collections;

public class InteractLoad : MonoBehaviour
{
    public InteractiveContainerSO InteractiveContainer;
    public GameObject ItemPrefab;
    public DialogContainerSO DialogContainer;

    // Use this for initialization
    void Start()
    {
        foreach (InteractiveSO interactiveItem in InteractiveContainer.InteractiveItemList)
        {
            GameObject go = Instantiate(ItemPrefab, transform);
            go.transform.position = interactiveItem.Coord;

            SpriteRenderer npcSprite = go.GetComponent<SpriteRenderer>();
            NPCController npcController = go.AddComponent<NPCController>();
            TalkController npcTalkController = go.AddComponent<TalkController>();

            foreach (DialogueSectionSO DialogueItem in DialogContainer.DialogueSectionList)
            {
                Debug.Log(DialogueItem.DialogueList[0].Content[0]);
                if (DialogueItem.NPCID == interactiveItem.ID)
                {
                    npcTalkController.DialogueSection = DialogueItem;
                }
            }

            npcSprite.sprite = interactiveItem.Icon;
            npcSprite.flipX = !interactiveItem.IsFaceRight;
            npcController.InteractiveItem = interactiveItem;
        }
    }
}
